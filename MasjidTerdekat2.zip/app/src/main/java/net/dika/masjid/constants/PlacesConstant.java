package net.dika.masjid.constants;

import net.dika.masjid.models.Results;

import java.util.ArrayList;
import java.util.List;

public class PlacesConstant {

    public static List<Results> results = new ArrayList<Results>();
}
